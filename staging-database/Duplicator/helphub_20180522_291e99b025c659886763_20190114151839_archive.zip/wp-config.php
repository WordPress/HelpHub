<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'helphub');

/** MySQL database username */
define('DB_USER', 'helphubuser');

/** MySQL database password */
define('DB_PASSWORD', 'XUNafL2rxehJAdzPUkoXtfis');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'w&Si~Cp}YHQ@I9rg*d-]JTssbz*$qm@wk0[VB7VGw@K3B>c+{M~L4P|--QNwQDt3');
define('SECURE_AUTH_KEY',  '-hTyqpa=|T5c[Z_F`f^ph;iAZyOtB~)^ujf-+ugFQj#TwVMD4&Zz2[i^gT(-~|=P');
define('LOGGED_IN_KEY',    'e+bgjXYG&z~,u3VDT *:TUC_kp-}]0<|3aRZN;Kl=*Z|!(.w3`DELNn[|6`N}IAl');
define('NONCE_KEY',        'B$kdw~n+rVK&b;JtEo1+x~MUE{-_gxg}R<opKYRl8b} .P=3KW{_iCo|FkxVtv4|');
define('AUTH_SALT',        '*ef/!<A$WIt-InhE~_4^3FR0R)NDz~UvBMSIbb%I/ nMx/R|K{la.m+x=Bnq`o8>');
define('SECURE_AUTH_SALT', 'p,yg+pnR!yy>a6-|Fo.:gto2:T4F*ih, h{:JUz3vR_+c)Id;93v=<Xp|S%JO}Y7');
define('LOGGED_IN_SALT',   '{#-IN/ =-Dd+@k6h~]w]zFWaQyP^Z8arD~Pj5stsCz%OK4b7j7_Xf!zX>]UK6g^>');
define('NONCE_SALT',       '?vCa+w7A%CdT-G0A3-`-5@68YnheZ3pd74zx;9 Ep$X~4-6eTTvVAhUhv9*Rh-u;');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'hh_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', true);

define('WP_DEBUG_DISPLAY', false);

define('WP_DEBUG_LOG', true);

//define( 'WPORGPATH', 'https://wordpress.org/' );

define('WP_MEMORY_LIMIT', '128M');

define('DISALLOW_FILE_EDIT', true);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
